
import React, { useState } from 'react';
import { CartItem } from '../types';

interface CheckoutViewProps {
  onBack: () => void;
  cart: CartItem[];
}

const CheckoutView: React.FC<CheckoutViewProps> = ({ onBack, cart }) => {
  const [showPaymentSheet, setShowPaymentSheet] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shippingFee = shippingMethod === 'express' ? 25 : 0;
  const tax = subtotal * 0.08;
  const total = subtotal + shippingFee + tax - discount;

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === 'TECHSTORE10') {
      setDiscount(subtotal * 0.1);
      alert('Mã giảm giá 10% đã được áp dụng!');
    } else {
      alert('Mã không hợp lệ');
    }
  };

  const handlePayNow = () => {
    setShowPaymentSheet(true);
  };

  const processPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2500);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center bg-background-dark">
        <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mb-8 animate-bounce shadow-lg shadow-green-500/20">
          <span className="material-symbols-outlined text-white text-6xl font-bold">check</span>
        </div>
        <h2 className="text-3xl font-black mb-3">Thanh toán thành công!</h2>
        <p className="text-gray-400 mb-10 max-w-[280px]">Đơn hàng #TECH-{(Math.random()*99999).toFixed(0)} của bạn đang được đóng gói và sẽ sớm được giao.</p>
        <button 
          onClick={onBack}
          className="w-full bg-primary py-4 rounded-2xl font-black text-white shadow-xl shadow-primary/30 active:scale-95 transition-transform"
        >
          TIẾP TỤC MUA SẮM
        </button>
      </div>
    );
  }

  return (
    <div className="pb-48 relative min-h-screen bg-background-dark">
      {/* Header */}
      <header className="sticky top-0 z-50 flex items-center bg-background-dark/95 p-4 border-b border-gray-800 backdrop-blur-md">
        <button onClick={onBack} className="size-10 flex items-center justify-center rounded-full bg-white/5"><span className="material-symbols-outlined">arrow_back</span></button>
        <h2 className="text-lg font-bold flex-1 text-center pr-10">Thủ tục thanh toán</h2>
      </header>

      <main className="px-4 py-6 space-y-8">
        {/* Shipping Address */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary">location_on</span>
            <h3 className="text-lg font-bold">Địa chỉ nhận hàng</h3>
          </div>
          <div className="bg-surface-dark p-4 rounded-2xl border border-gray-800 space-y-4 shadow-sm">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">Họ và tên</label>
                <input className="w-full bg-surface-dark-light border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary" defaultValue="Nguyễn Văn A" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">Số điện thoại</label>
                <input className="w-full bg-surface-dark-light border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary" defaultValue="0901234567" />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Địa chỉ chi tiết</label>
              <input className="w-full bg-surface-dark-light border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary" placeholder="Số nhà, tên đường..." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <input className="w-full bg-surface-dark-light border-none rounded-xl p-3 text-sm" placeholder="Quận/Huyện" />
              <input className="w-full bg-surface-dark-light border-none rounded-xl p-3 text-sm" placeholder="Thành phố" />
            </div>
          </div>
        </section>

        {/* Shipping Method */}
        <section className="space-y-4">
          <h3 className="text-lg font-bold">Phương thức vận chuyển</h3>
          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={() => setShippingMethod('standard')}
              className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${shippingMethod === 'standard' ? 'border-primary bg-primary/5' : 'border-gray-800 bg-surface-dark opacity-60'}`}
            >
              <div className="flex items-center gap-3 text-left">
                <span className="material-symbols-outlined">local_shipping</span>
                <div>
                  <p className="font-bold text-sm">Giao hàng tiêu chuẩn</p>
                  <p className="text-xs text-gray-500">Dự kiến nhận: 3-5 ngày</p>
                </div>
              </div>
              <span className="font-bold text-green-400 text-sm">Miễn phí</span>
            </button>
            <button 
              onClick={() => setShippingMethod('express')}
              className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${shippingMethod === 'express' ? 'border-primary bg-primary/5' : 'border-gray-800 bg-surface-dark opacity-60'}`}
            >
              <div className="flex items-center gap-3 text-left">
                <span className="material-symbols-outlined">bolt</span>
                <div>
                  <p className="font-bold text-sm">Giao hàng hỏa tốc</p>
                  <p className="text-xs text-gray-500">Dự kiến nhận: 24h</p>
                </div>
              </div>
              <span className="font-bold text-sm">$25.00</span>
            </button>
          </div>
        </section>

        {/* Promo Code */}
        <section className="space-y-4">
          <h3 className="text-lg font-bold">Mã giảm giá</h3>
          <div className="flex gap-2">
            <input 
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              className="flex-1 bg-surface-dark border-2 border-gray-800 rounded-xl px-4 py-3 text-sm uppercase font-bold tracking-widest placeholder:normal-case placeholder:font-normal" 
              placeholder="Nhập mã (TECHSTORE10)"
            />
            <button 
              onClick={handleApplyPromo}
              className="bg-white text-black px-6 rounded-xl font-bold text-sm active:scale-95 transition-transform"
            >
              ÁP DỤNG
            </button>
          </div>
        </section>

        {/* Order Summary */}
        <section className="bg-surface-dark rounded-3xl border border-gray-800 overflow-hidden shadow-xl">
          <div className="p-5 border-b border-gray-800 flex justify-between items-center">
            <h3 className="font-black text-sm uppercase tracking-widest text-gray-400">Tóm tắt đơn hàng</h3>
            <span className="bg-primary/20 text-primary text-[10px] font-black px-2 py-1 rounded-full">{cart.length} SẢN PHẨM</span>
          </div>
          <div className="p-5 space-y-4">
            <div className="flex justify-between text-sm text-gray-400"><span>Tạm tính</span><span className="text-white">${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm text-gray-400"><span>Phí vận chuyển</span><span className={shippingFee === 0 ? "text-green-400" : "text-white"}>{shippingFee === 0 ? "Miễn phí" : `$${shippingFee.toFixed(2)}`}</span></div>
            <div className="flex justify-between text-sm text-gray-400"><span>Thuế (8%)</span><span className="text-white">${tax.toFixed(2)}</span></div>
            {discount > 0 && (
              <div className="flex justify-between text-sm text-red-400 font-bold"><span>Giảm giá</span><span>-${discount.toFixed(2)}</span></div>
            )}
            <div className="h-px bg-gray-800 my-2"></div>
            <div className="flex justify-between items-center">
              <span className="text-lg font-black uppercase italic">Tổng cộng</span>
              <span className="text-2xl font-black text-primary">${total.toFixed(2)}</span>
            </div>
          </div>
        </section>
      </main>

      {/* Fixed Footer Buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-dark/95 backdrop-blur-2xl border-t border-gray-800 pb-safe z-40 flex flex-col gap-3">
        <button 
          onClick={handlePayNow}
          className="w-full bg-primary h-16 rounded-2xl font-black text-lg shadow-2xl shadow-primary/40 flex items-center justify-center gap-3 active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined">verified_user</span> THANH TOÁN NGAY
        </button>
        <button className="w-full border border-gray-800 h-12 rounded-xl font-bold text-gray-500 text-sm flex items-center justify-center gap-2 hover:bg-white/5 transition-colors">
          Thanh toán khi nhận hàng (COD)
        </button>
      </div>

      {/* Payment Sheet Overlay */}
      {showPaymentSheet && (
        <div className="fixed inset-0 z-[100] flex items-end">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={() => !isProcessing && setShowPaymentSheet(false)}></div>
          <div className="relative w-full bg-surface-dark rounded-t-[40px] p-8 animate-slide-up border-t border-white/10 shadow-[0_-20px_50px_rgba(0,0,0,0.5)]">
            <div className="w-16 h-1.5 bg-gray-700 rounded-full mx-auto mb-8"></div>
            
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-black italic uppercase">Xác nhận thanh toán</h3>
                <p className="text-xs text-gray-500 font-bold mt-1">Giao dịch an toàn 256-bit</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-gray-500 font-black uppercase">Tổng số tiền</p>
                <p className="text-2xl font-black text-primary">${total.toFixed(2)}</p>
              </div>
            </div>

            {/* Credit Card UI */}
            <div className="bg-gradient-to-br from-gray-800 to-black p-6 rounded-3xl border border-white/10 shadow-2xl mb-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-6"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" className="h-8" alt="Mastercard" /></div>
              <div className="mb-10"><span className="material-symbols-outlined text-4xl text-yellow-500/80">contactless</span></div>
              <p className="text-sm font-bold text-gray-500 mb-2 uppercase tracking-widest">Số thẻ</p>
              <p className="text-xl font-mono font-bold tracking-[0.25em] mb-8 text-white/90">•••• •••• •••• 4242</p>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-[10px] text-gray-500 uppercase font-bold">Chủ thẻ</p>
                  <p className="font-black text-sm tracking-widest uppercase">NGUYEN VAN A</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-gray-500 uppercase font-bold">Hết hạn</p>
                  <p className="font-bold text-sm">12/28</p>
                </div>
              </div>
              {/* Card Decoration */}
              <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
            </div>

            <button 
              disabled={isProcessing}
              onClick={processPayment}
              className={`w-full h-16 rounded-2xl font-black text-lg flex items-center justify-center gap-3 transition-all ${isProcessing ? 'bg-gray-800 cursor-not-allowed' : 'bg-primary hover:bg-blue-600 shadow-xl shadow-primary/30 active:scale-95'}`}
            >
              {isProcessing ? (
                <>
                  <div className="w-6 h-6 border-3 border-white/20 border-t-white rounded-full animate-spin"></div>
                  ĐANG XỬ LÝ...
                </>
              ) : (
                <>XÁC NHẬN VÀ TRẢ ${total.toFixed(2)}</>
              )}
            </button>
            
            <p className="text-center text-[10px] text-gray-500 mt-8 flex items-center justify-center gap-2 font-bold">
              <span className="material-symbols-outlined text-[14px] text-green-500">verified</span>
              THANH TOÁN ĐƯỢC BẢO MẬT BỞI TECHSTORE GATEWAY
            </p>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slide-up {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slide-up {
          animation: slide-up 0.5s cubic-bezier(0.2, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
};

export default CheckoutView;
