
import React from 'react';
import { Product } from '../types';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onAddToCart: () => void;
  onBuyNow: () => void;
}

const ProductDetailView: React.FC<ProductDetailProps> = ({ product, onBack, onAddToCart, onBuyNow }) => {
  return (
    <div className="pb-32">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 h-14 flex items-center px-4 justify-between">
        <button onClick={onBack} className="size-10 flex items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h2 className="text-base font-semibold">Product Details</h2>
        <div className="size-10 flex items-center justify-center relative">
          <span className="material-symbols-outlined">shopping_cart</span>
          <span className="absolute top-1 right-1 bg-primary text-[10px] text-white font-bold w-4 h-4 flex items-center justify-center rounded-full border border-background-dark">2</span>
        </div>
      </div>

      {/* Product Image Section */}
      <div className="p-6 flex flex-col items-center bg-white dark:bg-surface-dark/30">
        <div className="w-full aspect-[4/3] bg-center bg-contain bg-no-repeat mb-4 transition-transform hover:scale-105 duration-500" style={{ backgroundImage: `url('${product.image}')` }}></div>
        <div className="flex gap-2">
          <div className="w-2 h-2 rounded-full bg-primary"></div>
          <div className="w-2 h-2 rounded-full bg-gray-500/50"></div>
          <div className="w-2 h-2 rounded-full bg-gray-500/50"></div>
        </div>
      </div>

      <div className="px-4 flex flex-col gap-6 mt-6">
        {/* Title & Price */}
        <div className="flex justify-between items-start">
          <div className="flex-1 pr-4">
            <span className="inline-block px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider bg-primary/20 text-primary mb-2">New Arrival</span>
            <h1 className="text-2xl font-black tracking-tight leading-tight">{product.name}</h1>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex text-yellow-500">
                {[1, 2, 3, 4].map(i => <span key={i} className="material-symbols-outlined text-[16px] filled">star</span>)}
                <span className="material-symbols-outlined text-[16px]">star_half</span>
              </div>
              <span className="text-xs font-bold text-gray-500">{product.rating} ({product.reviews} Reviews)</span>
            </div>
          </div>
          <button className="p-3 rounded-2xl bg-gray-100 dark:bg-surface-dark text-gray-400 hover:text-red-500 transition-colors">
            <span className="material-symbols-outlined filled">favorite</span>
          </button>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-primary">${product.price}</span>
          {product.originalPrice && <span className="text-sm text-gray-500 line-through font-medium">${product.originalPrice}</span>}
        </div>

        <div className="p-4 rounded-2xl bg-primary/5 border border-primary/10">
          <p className="text-sm text-gray-400 leading-relaxed italic">"{product.description}"</p>
        </div>

        <hr className="border-gray-200 dark:border-gray-800" />

        {/* Color Selection */}
        <div>
          <h3 className="text-sm font-bold mb-4 uppercase tracking-widest text-gray-500">Select Color</h3>
          <div className="flex gap-4">
            <button className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 rounded-full bg-[#2e2e2e] ring-2 ring-primary ring-offset-4 ring-offset-background-dark shadow-lg"></div>
              <span className="text-[10px] font-bold text-primary uppercase">Midnight</span>
            </button>
            <button className="flex flex-col items-center gap-2 opacity-40">
              <div className="w-12 h-12 rounded-full bg-[#e3e4e6]"></div>
              <span className="text-[10px] font-bold uppercase">Starlight</span>
            </button>
          </div>
        </div>

        {/* Memory selection */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-500">Storage Capacity</h3>
            <span className="text-[10px] text-primary font-black uppercase underline cursor-pointer">Size Guide</span>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <button className="flex items-center justify-between p-4 rounded-2xl border-2 border-primary bg-primary/10 shadow-sm">
              <div className="text-left">
                <p className="font-black text-sm">512GB SSD Storage</p>
                <p className="text-[10px] text-gray-500 font-bold uppercase">Recommended for creators</p>
              </div>
              <span className="material-symbols-outlined text-primary filled">check_circle</span>
            </button>
            <button className="flex items-center justify-between p-4 rounded-2xl border-2 border-transparent bg-gray-100 dark:bg-surface-dark opacity-50">
              <div className="text-left">
                <p className="font-bold text-sm">1TB SSD Storage</p>
                <p className="text-[10px] text-gray-500 font-bold uppercase">+$200.00</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-xl border-t border-gray-200 dark:border-gray-800 pb-safe z-50">
        <div className="max-w-md mx-auto flex items-center gap-3">
          {/* Price Display */}
          <div className="flex flex-col pr-2 min-w-[70px]">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">Total</span>
            <span className="text-lg font-black text-primary">${product.price}</span>
          </div>
          
          {/* Add to Cart Button - Now links to Cart View */}
          <button 
            onClick={onAddToCart} 
            className="flex-1 h-14 bg-surface-dark-light hover:bg-surface-dark border border-white/5 font-bold rounded-2xl transition-all active:scale-95 flex items-center justify-center gap-2 shadow-lg"
          >
            <span className="material-symbols-outlined text-lg">add_shopping_cart</span>
            <span className="text-xs font-bold uppercase tracking-tight">Thêm giỏ hàng</span>
          </button>
          
          {/* Buy Now Button - Direct to Checkout */}
          <button 
            onClick={onBuyNow}
            className="flex-1 h-14 bg-primary text-white font-black rounded-2xl shadow-xl shadow-primary/30 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-lg">shopping_bag</span>
            <span className="text-xs font-bold uppercase tracking-tight">Mua ngay</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailView;
