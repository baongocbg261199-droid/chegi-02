
import React from 'react';
import { View } from '../types';

interface BottomNavProps {
  currentView: View;
  onNavigate: (view: View) => void;
  cartCount: number;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate, cartCount }) => {
  const tabs = [
    { view: 'HOME', icon: 'home', label: 'Home' },
    { view: 'CATALOG', icon: 'grid_view', label: 'Browse' },
    { view: 'DASHBOARD', icon: 'dashboard', label: 'Dashboard' },
    { view: 'CART', icon: 'shopping_bag', label: 'Cart', count: cartCount },
    { view: 'ACCOUNT', icon: 'person', label: 'Account' }
  ];

  return (
    <nav className="fixed bottom-0 w-full max-w-md bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-lg border-t border-gray-200 dark:border-gray-800 pb-safe z-[60]">
      <div className="flex items-center justify-around h-16">
        {tabs.map(tab => (
          <button 
            key={tab.view}
            onClick={() => onNavigate(tab.view as View)}
            className={`flex flex-col items-center gap-1 p-2 transition-colors relative ${currentView === tab.view ? 'text-primary' : 'text-gray-500'}`}
          >
            <span className={`material-symbols-outlined text-2xl ${currentView === tab.view ? 'filled' : ''}`}>{tab.icon}</span>
            <span className="text-[10px] font-medium">{tab.label}</span>
            {tab.count !== undefined && tab.count > 0 && (
              <span className="absolute top-1.5 right-2 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[8px] font-bold text-white ring-2 ring-background-dark">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;
