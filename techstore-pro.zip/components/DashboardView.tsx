
import React from 'react';

const DashboardView: React.FC = () => {
  const categoryStats = [
    { label: 'Phones', value: 45, color: 'bg-blue-500' },
    { label: 'Laptops', value: 30, color: 'bg-purple-500' },
    { label: 'Audio', value: 65, color: 'bg-emerald-500' },
    { label: 'Watch', value: 25, color: 'bg-orange-500' },
  ];

  const revenueData = [
    { label: 'Hardware', percent: 60, color: 'border-blue-500' },
    { label: 'Service', percent: 25, color: 'border-purple-500' },
    { label: 'Accs', percent: 15, color: 'border-orange-500' },
  ];

  return (
    <div className="pb-32 min-h-screen bg-background-dark text-white">
      <header className="sticky top-0 z-50 bg-background-dark/90 backdrop-blur-md border-b border-gray-800 p-4 flex items-center justify-between">
        <h2 className="text-xl font-black uppercase italic tracking-tighter">Business Insights</h2>
        <button className="p-2 rounded-xl bg-surface-dark border border-gray-700">
          <span className="material-symbols-outlined text-gray-400">calendar_today</span>
        </button>
      </header>

      <main className="p-4 space-y-6">
        {/* AOV Card */}
        <section className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-primary to-blue-700 p-5 rounded-[32px] shadow-xl shadow-primary/20 relative overflow-hidden group">
            <div className="relative z-10">
              <p className="text-[10px] font-black uppercase tracking-widest text-white/70 mb-1">Avg Order Value</p>
              <h3 className="text-3xl font-black tracking-tighter">$842.50</h3>
              <div className="flex items-center gap-1 mt-3 text-white text-[10px] font-bold bg-white/20 w-fit px-2 py-1 rounded-full">
                <span className="material-symbols-outlined text-xs">trending_up</span> +12%
              </div>
            </div>
            <span className="material-symbols-outlined absolute -right-4 -bottom-4 text-8xl text-white/10 rotate-12 group-hover:rotate-0 transition-transform duration-500">payments</span>
          </div>

          <div className="bg-surface-dark border border-gray-800 p-5 rounded-[32px] flex flex-col justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1">Total Orders</p>
              <h3 className="text-3xl font-black tracking-tighter">1,284</h3>
            </div>
            <div className="flex items-center gap-1 text-emerald-500 text-[10px] font-bold mt-3">
              <span className="material-symbols-outlined text-xs">check_circle</span> 98% Fulfilled
            </div>
          </div>
        </section>

        {/* Product Volume - Bar Chart */}
        <section className="bg-surface-dark border border-gray-800 p-6 rounded-[32px]">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-sm font-black uppercase tracking-widest text-gray-400">Inventory Volume</h3>
            <span className="text-[10px] font-bold text-primary">Units by Category</span>
          </div>
          <div className="flex items-end justify-around h-40 gap-2">
            {categoryStats.map((item) => (
              <div key={item.label} className="flex flex-col items-center gap-3 flex-1 group">
                <div className="w-full relative flex items-end justify-center h-32">
                  <div 
                    className={`${item.color} w-8 rounded-t-lg transition-all duration-700 group-hover:brightness-125`} 
                    style={{ height: `${item.value}%` }}
                  >
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-black opacity-0 group-hover:opacity-100 transition-opacity">
                      {item.value}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-gray-500 uppercase">{item.label}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Revenue Share - Pie Chart Simulation */}
        <section className="bg-surface-dark border border-gray-800 p-6 rounded-[32px]">
          <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 mb-8">Revenue Distribution</h3>
          <div className="flex items-center gap-8">
            <div className="relative size-32">
              {/* Fake Pie Chart using Borders */}
              <div className="absolute inset-0 rounded-full border-[12px] border-blue-500/20"></div>
              <div className="absolute inset-0 rounded-full border-[12px] border-blue-500 border-t-transparent border-r-transparent rotate-45"></div>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-xl font-black tracking-tighter">$42K</span>
                <span className="text-[8px] font-bold text-gray-500 uppercase">Monthly</span>
              </div>
            </div>
            <div className="flex-1 space-y-4">
              {revenueData.map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`size-2 rounded-full ${item.color.replace('border-', 'bg-')}`}></div>
                    <span className="text-xs font-bold text-gray-400">{item.label}</span>
                  </div>
                  <span className="text-xs font-black">{item.percent}%</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Recent Activity */}
        <section className="space-y-4">
          <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 px-2">Live Sales</h3>
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-surface-dark/50 p-4 rounded-2xl flex items-center justify-between border border-gray-800/50">
                <div className="flex items-center gap-3">
                  <div className="size-10 bg-gray-800 rounded-full flex items-center justify-center">
                    <span className="material-symbols-outlined text-primary text-sm">shopping_bag</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold">New order from #TK-{9000 + i}</p>
                    <p className="text-[10px] text-gray-500">Just now • 2 items</p>
                  </div>
                </div>
                <span className="text-sm font-black">+$1,240</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default DashboardView;
