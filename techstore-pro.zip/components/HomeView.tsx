
import React, { useEffect, useState } from 'react';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Product } from '../types';

interface HomeViewProps {
  onNavigate: (product: Product) => void;
  onSeeAll: () => void;
}

const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onSeeAll }) => {
  const [scrollIndex, setScrollIndex] = useState(0);

  // Slideshow logic: chạy từ trái qua phải liên tục
  useEffect(() => {
    const interval = setInterval(() => {
      setScrollIndex((prev) => (prev + 1) % 3);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const banners = [
    {
      title: "iPhone 15 Pro",
      desc: "Titanium design",
      tag: "New",
      img: "https://lh3.googleusercontent.com/aida-public/AB6AXuBPV59IY0RazCwhYXcldunIdXbG8-D_4uqEFYaEFhhynk50FheDB__i9SrgWiSKjAkjsCmod7EkBhENnsIsbBPOvugBKXgIxx-SvBkPxvoK9QyS5iZ1e3FBtcNdwJug302clWUkCZ2qxlXzXLK3nr8hc5r5u1vmOYoeDbXJZoWRhZ_CaVUPevmRc8ixIE1HzZW4jZrv_VW_XxioIyhOasrriw5KL5wDE2SVYX1-A5pIxraqjoZfnYHb80BpguLwhtTaqg2kjnjlF9yi",
      color: "from-blue-600/80"
    },
    {
      title: "MacBook M3",
      desc: "Mind-blowing speed",
      tag: "Pro",
      img: "https://lh3.googleusercontent.com/aida-public/AB6AXuACoorgp-MkKLtN8vYohe4ObtLE7OKyeUFXVIwDlA8yTHmK5F2trz48x4wZW6VFjUHAkcBdBxLGHmGkYi891T8MsJeMTNLnVZUn8Ia1oWN2XABizbd7GYJvwvZYxtWHn6TJ-Ul30FN1TOt60XtOhgLFxy7Kh8lOQsbpNMdAcSl6FtGst5C60jgcGoZnHEYZC0ANy7u35YoRKvYm2a0WZTW1rBrh1_qw-Bi2GEJNzTh8GNVkodjGDBJV_e6A0t3c9H49oPaXJTvBeK-o",
      color: "from-purple-600/80"
    },
    {
      title: "Watch Ultra 2",
      desc: "Adventure ready",
      tag: "Sport",
      img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAWzvAYfih1OEgYUyEgK7-F-YzlGjWxirJTWuS_UU9gbR1rb7yRR2uctw2UTcAGMF6gtBtxvMCcgNA2RdG0-ghvvu1i4PL6P1IsF1LyKUHaI8r7_nWXhKsov-v2b-qbykUFlE0Cy6aP3rKZH52dv26vE2Shwy2IcKWd6XEtSfL251VHZOrVU_F44kljNuSLFW_zwoJ3eXLt2OJEyS_wtTkizYdbmQSb2V8OrfQIZnRCSPnx8f_7LFIjFw3EIh6x6YF9s31HDfxbXPDM",
      color: "from-orange-600/80"
    }
  ];

  return (
    <div className="pb-24">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 p-4 h-16 flex items-center justify-between">
        <button className="p-2 -ml-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
          <span className="material-symbols-outlined">menu</span>
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-xl">T</div>
          <h1 className="text-xl font-bold tracking-tight">TechStore</h1>
        </div>
        <button className="relative p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
          <span className="material-symbols-outlined">shopping_cart</span>
          <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border-2 border-background-light dark:border-background-dark">2</span>
        </button>
      </header>

      {/* Search Bar */}
      <div className="px-4 py-4 sticky top-16 z-40 bg-background-light dark:bg-background-dark">
        <div className="relative">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">search</span>
          <input 
            className="block w-full pl-10 pr-10 py-3 rounded-xl border-none bg-white dark:bg-surface-dark text-gray-900 dark:text-white placeholder-gray-500 focus:ring-2 focus:ring-primary shadow-sm" 
            placeholder="Search phones, laptops..." 
            type="text"
          />
          <button className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-primary">mic</button>
        </div>
      </div>

      {/* Small Dual Banner Slideshow */}
      <section className="px-4 overflow-hidden relative">
        <div 
          className="flex transition-transform duration-500 ease-in-out gap-3"
          style={{ transform: `translateX(-${scrollIndex * 60}%)` }}
        >
          {banners.map((banner, i) => (
            <div 
              key={i} 
              className="shrink-0 w-[80%] relative overflow-hidden rounded-2xl h-[160px] bg-gray-900 shadow-xl"
            >
              <div className="absolute inset-0 bg-cover bg-center opacity-70" style={{ backgroundImage: `url('${banner.img}')` }}></div>
              <div className={`absolute inset-0 bg-gradient-to-r ${banner.color} to-transparent`}></div>
              <div className="relative h-full flex flex-col justify-center px-4 items-start z-10">
                <span className="bg-white/20 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded mb-1 uppercase">{banner.tag}</span>
                <h2 className="text-white text-lg font-bold leading-tight">{banner.title}</h2>
                <p className="text-gray-200 text-xs mb-3">{banner.desc}</p>
                <button className="bg-white text-black text-[10px] font-bold px-3 py-1.5 rounded-md hover:bg-gray-100 transition-colors uppercase">Explore</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Category Chips */}
      <section className="mt-6">
        <div className="flex gap-3 px-4 overflow-x-auto scrollbar-hide pb-2">
          {['All', 'Phones', 'Laptops', 'Audio', 'Wearables'].map((cat, i) => (
            <button key={cat} className={`flex items-center gap-2 px-5 py-2.5 rounded-full shrink-0 border transition-all ${i === 0 ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20' : 'bg-white dark:bg-surface-dark text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'}`}>
              <span className="text-sm font-semibold">{cat}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Categories Grid */}
      <section className="mt-6 px-4">
        <h3 className="text-lg font-bold mb-3">Featured</h3>
        <div className="grid grid-cols-4 gap-3">
          {CATEGORIES.map(cat => (
            <div key={cat.name} className="flex flex-col items-center gap-2">
              <div className={`w-16 h-16 rounded-2xl bg-${cat.color}-100 dark:bg-${cat.color}-900/30 flex items-center justify-center text-${cat.color}-600`}>
                <span className="material-symbols-outlined text-3xl">{cat.icon}</span>
              </div>
              <span className="text-xs font-medium text-gray-600 dark:text-gray-400">{cat.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Flash Sales */}
      <section className="mt-8 px-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold">Flash Sales</h3>
            <div className="flex items-center gap-1 bg-red-100 dark:bg-red-900/30 px-2 py-0.5 rounded text-red-600 dark:text-red-400 text-xs font-bold">
              <span className="material-symbols-outlined text-sm">bolt</span>
              <span>02:14:55</span>
            </div>
          </div>
          <button onClick={onSeeAll} className="text-primary text-sm font-semibold">See All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
          {PRODUCTS.slice(2).map(prod => (
            <div key={prod.id} onClick={() => onNavigate(prod)} className="min-w-[160px] w-[160px] bg-white dark:bg-surface-dark rounded-xl p-3 flex flex-col gap-3 shadow-sm border border-gray-100 dark:border-gray-800 cursor-pointer">
              <div className="w-full aspect-square rounded-lg bg-gray-100 dark:bg-gray-800 relative overflow-hidden group">
                <div className="absolute top-2 left-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">-25%</div>
                <img src={prod.image} alt={prod.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
              </div>
              <div className="flex flex-col gap-1">
                <h4 className="text-sm font-medium line-clamp-2 h-10">{prod.name}</h4>
                <div className="flex items-end gap-2 mt-1">
                  <span className="text-primary font-bold text-base">${prod.price}</span>
                  {prod.originalPrice && <span className="text-gray-400 text-xs line-through mb-0.5">${prod.originalPrice}</span>}
                </div>
                <button className="mt-2 w-full h-8 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1">
                  Add <span className="material-symbols-outlined text-sm">add</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      <section className="mt-8 px-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">New Arrivals</h3>
          <div className="flex gap-2">
            <button className="bg-primary text-white p-1 rounded"><span className="material-symbols-outlined text-lg">grid_view</span></button>
            <button className="text-gray-400 p-1"><span className="material-symbols-outlined text-lg">view_list</span></button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {PRODUCTS.slice(0, 4).map(prod => (
            <div key={prod.id} onClick={() => onNavigate(prod)} className="group flex flex-col gap-3 cursor-pointer">
              <div className="relative w-full aspect-[4/5] rounded-xl overflow-hidden bg-white dark:bg-surface-dark border border-gray-100 dark:border-gray-800">
                <button className="absolute top-2 right-2 z-10 p-1.5 rounded-full bg-black/20 text-white hover:bg-red-500 transition-colors backdrop-blur-sm">
                  <span className="material-symbols-outlined text-lg">favorite</span>
                </button>
                <img src={prod.image} alt={prod.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div>
                <div className="flex items-center gap-1 mb-1">
                  <span className="material-symbols-outlined text-yellow-400 text-sm filled">star</span>
                  <span className="text-xs font-medium text-gray-500 dark:text-gray-400">{prod.rating} ({prod.reviews})</span>
                </div>
                <h4 className="text-sm font-medium line-clamp-2 leading-snug">{prod.name}</h4>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-lg font-bold text-white">${prod.price}</span>
                  <button className="bg-primary text-white w-8 h-8 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-colors">
                    <span className="material-symbols-outlined text-lg">shopping_bag</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <button onClick={onSeeAll} className="w-full py-3 rounded-xl border border-gray-700 text-gray-300 font-medium hover:bg-surface-dark transition-colors">View All Products</button>
        </div>
      </section>
    </div>
  );
};

export default HomeView;
