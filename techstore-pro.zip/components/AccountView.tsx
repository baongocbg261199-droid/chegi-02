
import React from 'react';

const AccountView: React.FC = () => {
  return (
    <div className="pb-24">
      <header className="sticky top-0 z-50 bg-background-dark/90 backdrop-blur-md border-b border-gray-800 p-4 h-16 flex items-center justify-center">
        <h2 className="text-xl font-bold">My Account</h2>
        <button className="absolute right-4 p-2 rounded-full hover:bg-gray-800 transition-colors"><span className="material-symbols-outlined">settings</span></button>
      </header>

      <div className="px-4 py-8 flex flex-col items-center gap-4 text-center">
        <div className="relative">
          <div className="h-24 w-24 rounded-full ring-4 ring-primary/20 bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/id/64/200/200')" }}></div>
          <button className="absolute bottom-0 right-0 bg-surface-dark border border-gray-700 rounded-full p-1.5"><span className="material-symbols-outlined text-[16px] block">edit</span></button>
        </div>
        <div>
          <h1 className="text-2xl font-bold">Alex Doe</h1>
          <p className="text-gray-500 text-sm font-medium">alex.doe@example.com</p>
        </div>
      </div>

      <div className="border-b border-gray-800 flex px-4 gap-6 scrollbar-hide overflow-x-auto sticky top-16 bg-background-dark z-40">
        <button className="border-b-2 border-primary pb-3 pt-2 font-bold text-sm text-primary">My Orders</button>
        <button className="pb-3 pt-2 font-bold text-sm text-gray-500">My Profile</button>
        <button className="pb-3 pt-2 font-bold text-sm text-gray-500">Notifications</button>
      </div>

      <div className="p-4 flex flex-col gap-4">
        {[
          { id: '4921', status: 'Processing', date: 'Oct 25', name: 'MacBook Pro M2', price: '2,499.00', color: 'primary' },
          { id: '4892', status: 'Delivered', date: 'Oct 20', name: 'Sony WH-1000XM5', price: '348.00', color: 'emerald' }
        ].map(order => (
          <div key={order.id} className="bg-surface-dark p-4 rounded-xl border border-gray-800 space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex flex-col gap-1">
                <span className={`flex items-center gap-1.5 text-${order.color}-500 text-xs font-bold uppercase`}>
                  <span className={`w-2 h-2 rounded-full bg-${order.color}-500`}></span> {order.status}
                </span>
                <p className="text-gray-500 text-xs">Order #ORD-{order.id}</p>
              </div>
              <span className="text-xs text-gray-500">{order.date}</span>
            </div>
            <div className="flex gap-4 items-center">
              <div className="size-16 bg-gray-800 rounded-lg"></div>
              <div className="flex-1">
                <h3 className="font-bold">{order.name}</h3>
                <p className="text-xs text-gray-500">Standard Configuration</p>
                <p className="font-bold mt-1">${order.price}</p>
              </div>
            </div>
            <button className="w-full bg-primary/10 text-primary py-2.5 rounded-lg text-sm font-bold">View Details</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AccountView;
