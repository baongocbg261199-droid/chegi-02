
import React from 'react';
import { PRODUCTS } from '../constants';
import { Product } from '../types';

interface CatalogViewProps {
  onBack: () => void;
  onProductClick: (product: Product) => void;
}

const CatalogView: React.FC<CatalogViewProps> = ({ onBack, onProductClick }) => {
  return (
    <div className="pb-24">
      <div className="sticky top-0 z-50 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center p-4 pb-2 justify-between">
          <button onClick={onBack} className="size-10 flex items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h2 className="text-lg font-bold">Laptops</h2>
          <div className="size-10 flex items-center justify-center relative">
            <span className="material-symbols-outlined">shopping_cart</span>
            <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-white">2</span>
          </div>
        </div>
        <div className="px-4 py-3">
          <div className="flex w-full items-stretch rounded-xl h-12 bg-white dark:bg-surface-dark-light">
            <div className="text-gray-500 flex items-center justify-center pl-4"><span className="material-symbols-outlined">search</span></div>
            <input className="flex w-full bg-transparent border-none text-base focus:ring-0 placeholder-gray-400 pl-2" placeholder="Search MacBook, XPS..." />
          </div>
        </div>
      </div>

      <div className="px-4 pt-4 flex items-baseline justify-between">
        <h3 className="text-xl font-bold">142 Results</h3>
        <span className="text-sm text-primary font-medium">Sort by: Popular</span>
      </div>

      <div className="flex gap-3 p-4 overflow-x-auto scrollbar-hide">
        <button className="flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-full bg-slate-900 dark:bg-white px-4">
          <span className="material-symbols-outlined dark:text-black">tune</span>
          <p className="dark:text-black text-sm font-semibold">Filters</p>
        </button>
        <button className="flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-full bg-primary/20 border border-primary/30 px-4">
          <span className="material-symbols-outlined text-primary">check</span>
          <p className="text-primary text-sm font-medium">In Stock</p>
        </button>
        {['Apple', '32GB RAM', 'Under $1500'].map(chip => (
          <button key={chip} className="flex h-9 shrink-0 items-center justify-center px-4 rounded-full bg-white dark:bg-surface-dark-light border border-gray-200 dark:border-gray-700 whitespace-nowrap">
            <p className="text-sm font-medium">{chip}</p>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 px-4 pb-4">
        {PRODUCTS.map(prod => (
          <div key={prod.id} onClick={() => onProductClick(prod)} className="group flex flex-col bg-white dark:bg-surface-dark rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow relative cursor-pointer">
            {prod.tags && <div className="absolute top-2 left-2 z-10 bg-primary text-white text-[10px] font-bold px-2 py-1 rounded-md">NEW</div>}
            <div className="aspect-square w-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center p-4">
              <img src={prod.image} alt={prod.name} className="object-contain h-full w-full group-hover:scale-105 transition-transform" />
            </div>
            <div className="p-3 flex flex-col flex-1">
              <h4 className="text-sm font-bold line-clamp-2 mb-1">{prod.name}</h4>
              <p className="text-gray-500 text-xs mb-2">M2 • 8GB • 256GB</p>
              <div className="mt-auto flex items-end justify-between">
                <div className="flex flex-col">
                  {prod.originalPrice && <span className="text-xs text-gray-400 line-through">${prod.originalPrice}</span>}
                  <span className="text-primary font-bold text-base">${prod.price}</span>
                </div>
                <button className="size-8 rounded-full bg-primary flex items-center justify-center text-white shadow-lg active:scale-95"><span className="material-symbols-outlined text-[18px]">add</span></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CatalogView;
