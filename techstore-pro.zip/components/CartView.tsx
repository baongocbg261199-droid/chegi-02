
import React from 'react';
import { CartItem } from '../types';

interface CartViewProps {
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
  onBack: () => void;
  onCheckout: () => void;
}

const CartView: React.FC<CartViewProps> = ({ items, onUpdateQuantity, onRemove, onBack, onCheckout }) => {
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  return (
    <div className="pb-32">
      <header className="sticky top-0 z-50 flex items-center justify-between bg-background-dark/95 px-4 py-3 backdrop-blur-md border-b border-white/5">
        <button onClick={onBack} className="size-10 flex items-center justify-center rounded-full hover:bg-white/10"><span className="material-symbols-outlined">arrow_back</span></button>
        <h1 className="text-lg font-bold">My Cart ({items.length})</h1>
        <button className="text-sm font-semibold text-gray-500">Clear</button>
      </header>

      <main className="p-4 flex flex-col gap-4">
        {items.length === 0 ? (
          <div className="text-center py-20 text-gray-500">Your cart is empty</div>
        ) : (
          items.map(item => (
            <div key={item.id} className="flex flex-col gap-3 rounded-xl bg-surface-dark p-3 border border-white/5">
              <div className="flex gap-4">
                <div className="size-24 rounded-lg bg-white/5 overflow-hidden"><img src={item.image} className="h-full w-full object-cover" /></div>
                <div className="flex-1 flex flex-col justify-between py-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold">{item.name}</h3>
                    <button onClick={() => onRemove(item.id)} className="text-gray-500"><span className="material-symbols-outlined">delete</span></button>
                  </div>
                  <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                  <p className="font-bold">${item.price}</p>
                </div>
              </div>
              <div className="flex items-center justify-between border-t border-white/5 pt-3">
                <span className="text-xs text-green-400">In Stock</span>
                <div className="flex items-center gap-3 rounded-lg bg-black/20 px-2 py-1">
                  <button onClick={() => onUpdateQuantity(item.id, -1)} className="size-7 bg-surface-dark-light rounded-full flex items-center justify-center shadow-sm"><span className="material-symbols-outlined text-[16px]">remove</span></button>
                  <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                  <button onClick={() => onUpdateQuantity(item.id, 1)} className="size-7 bg-surface-dark-light rounded-full flex items-center justify-center shadow-sm"><span className="material-symbols-outlined text-[16px]">add</span></button>
                </div>
              </div>
            </div>
          ))
        )}

        <div className="bg-surface-dark p-4 rounded-xl border border-white/5 mt-4">
          <h3 className="text-lg font-bold mb-4">Order Summary</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-400"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-gray-400"><span>Shipping</span><span className="text-green-400">Free</span></div>
            <div className="flex justify-between text-gray-400"><span>Tax (8%)</span><span>${tax.toFixed(2)}</span></div>
            <div className="h-px bg-white/10 my-2"></div>
            <div className="flex justify-between items-center text-lg font-bold"><span>Total</span><span className="text-primary">${total.toFixed(2)}</span></div>
          </div>
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-dark/95 backdrop-blur-lg border-t border-white/10 pb-safe">
        <div className="flex items-center justify-between px-1">
          <div className="flex flex-col"><span className="text-xs text-gray-400">Total</span><span className="text-lg font-bold">${total.toFixed(2)}</span></div>
          <button onClick={onCheckout} className="bg-primary px-8 py-3.5 rounded-full font-bold shadow-lg shadow-primary/30 flex items-center gap-2">
            Checkout <span className="material-symbols-outlined">arrow_forward</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartView;
